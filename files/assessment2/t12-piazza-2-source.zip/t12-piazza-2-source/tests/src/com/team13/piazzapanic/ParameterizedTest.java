package com.team13.piazzapanic;

public @interface ParameterizedTest {
}
