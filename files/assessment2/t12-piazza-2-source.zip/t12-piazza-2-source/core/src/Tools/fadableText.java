package Tools;

public class fadableText {
}
