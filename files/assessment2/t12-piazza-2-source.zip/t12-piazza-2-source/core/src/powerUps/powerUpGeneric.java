package powerUps;

import Sprites.Chef;
import Sprites.OrderTimer;
import com.team13.piazzapanic.HUD;

/**
 * This class shows the outline of how a powerup for a chef should be inplemented.
 */

public class powerUpGeneric {

    public void improveChef(Chef chefToModify, OrderTimer orderTimer, HUD hud) {
    }

}
